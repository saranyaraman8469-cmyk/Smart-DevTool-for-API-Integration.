import unittest
from client import ApiClient

class TestApiClient(unittest.TestCase):
    def setUp(self):
        self.client = ApiClient(api_key='test_key')

    def test_initialization(self):
        self.assertIsNotNone(self.client)

if __name__ == '__main__':
    unittest.main()
