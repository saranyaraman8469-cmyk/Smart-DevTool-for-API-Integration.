```python
import logging
import time
from typing import Any, Dict, Optional, Union, Iterator, List

import requests
from requests.auth import HTTPBasicAuth
from tenacity import (
    retry,
    stop_after_attempt,
    wait_exponential,
    retry_if_exception_type,
    before_sleep_log,
)

# Configure logging
logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO)
handler = logging.StreamHandler()
formatter = logging.Formatter("%(asctime)s - %(name)s - %(levelname)s - %(message)s")
handler.setFormatter(formatter)
if not logger.handlers:
    logger.addHandler(handler)


class TwilioAPIError(Exception):
    """Base exception for Twilio API errors."""

    def __init__(self, message: str, status_code: Optional[int] = None, response_data: Optional[Dict] = None):
        super().__init__(message)
        self.status_code = status_code
        self.response_data = response_data

    def __str__(self):
        if self.status_code and self.response_data:
            return f"TwilioAPIError: Status {self.status_code} - {self.response_data.get('message', self.response_data)} - {self.args[0]}"
        elif self.status_code:
            return f"TwilioAPIError: Status {self.status_code} - {self.args[0]}"
        return f"TwilioAPIError: {self.args[0]}"


class TwilioBadRequestError(TwilioAPIError):
    """Raised for 400 Bad Request errors."""
    pass


class TwilioUnauthorizedError(TwilioAPIError):
    """Raised for 401 Unauthorized errors."""
    pass


class TwilioForbiddenError(TwilioAPIError):
    """Raised for 403 Forbidden errors."""
    pass


class TwilioNotFoundError(TwilioAPIError):
    """Raised for 404 Not Found errors."""
    pass


class TwilioRateLimitError(TwilioAPIError):
    """Raised for 429 Too Many Requests errors."""
    pass


class TwilioClientError(TwilioAPIError):
    """Raised for other 4xx client errors."""
    pass


class TwilioServerError(TwilioAPIError):
    """Raised for 5xx server errors."""
    pass


class TwilioClient:
    """
    A robust Python SDK wrapper for the Twilio API.

    This client handles authentication, error handling, retry strategies with
    exponential backoff, timeout settings, and logging.
    """

    DEFAULT_BASE_URL = "https://api.twilio.com"
    DEFAULT_TIMEOUT = 30  # seconds

    def __init__(
        self,
        account_sid: str,
        auth_token: str,
        base_url: Optional[str] = None,
        timeout: Optional[int] = None,
        max_retries: int = 5,
        retry_wait_min: int = 4,
        retry_wait_max: int = 60,
    ):
        """
        Initializes the TwilioClient.

        Args:
            account_sid: Your Twilio Account SID.
            auth_token: Your Twilio Auth Token.
            base_url: The base URL for the Twilio API. Defaults to https://api.twilio.com.
            timeout: Default request timeout in seconds. Defaults to 30 seconds.
            max_retries: Maximum number of retry attempts for transient errors (429, 5xx).
            retry_wait_min: Minimum wait time between retries in seconds.
            retry_wait_max: Maximum wait time between retries in seconds.
        """
        if not account_sid or not auth_token:
            raise ValueError("Account SID and Auth Token must be provided.")

        self.account_sid = account_sid
        self.auth_token = auth_token
        self.base_url = base_url or self.DEFAULT_BASE_URL
        self.timeout = timeout or self.DEFAULT_TIMEOUT
        self.max_retries = max_retries
        self.retry_wait_min = retry_wait_min
        self.retry_wait_max = retry_wait_max

        self._session = requests.Session()
        self._session.auth = HTTPBasicAuth(self.account_sid, self.auth_token)

        logger.info(f"TwilioClient initialized for Account SID: {self.account_sid[:5]}... (base_url: {self.base_url})")

    def _handle_response(self, response: requests.Response) -> Dict[str, Any]:
        """
        Handles the HTTP response, checking for errors and raising appropriate exceptions.

        Args:
            response: The requests.Response object.

        Returns:
            The JSON response body.

        Raises:
            TwilioAPIError: For various API errors based on status code.
            requests.RequestException: For network-related errors.
        """
        try:
            response_data = response.json()
        except requests.exceptions.JSONDecodeError:
            response_data = {"message": response.text}

        if 200 <= response.status_code < 300:
            return response_data
        elif response.status_code == 400:
            raise TwilioBadRequestError(
                f"Bad Request: {response_data.get('message', 'Invalid request parameters.')}",
                status_code=response.status_code,
                response_data=response_data,
            )
        elif response.status_code == 401:
            raise TwilioUnauthorizedError(
                f"Unauthorized: {response_data.get('message', 'Authentication failed.')}",
                status_code=response.status_code,
                response_data=response_data,
            )
        elif response.status_code == 403:
            raise TwilioForbiddenError(
                f"Forbidden: {response_data.get('message', 'Access to resource forbidden.')}",
                status_code=response.status_code,
                response_data=response_data,
            )
        elif response.status_code == 404:
            raise TwilioNotFoundError(
                f"Not Found: {response_data.get('message', 'Resource not found.')}",
                status_code=response.status_code,
                response_data=response_data,
            )
        elif response.status_code == 429:
            raise TwilioRateLimitError(
                f"Rate Limit Exceeded: {response_data.get('message', 'Too many requests.')}",
                status_code=response.status_code,
                response_data=response_data,
            )
        elif 400 <= response.status_code < 500:
            raise TwilioClientError(
                f"Client Error: {response_data.get('message', 'An unexpected client error occurred.')}",
                status_code=response.status_code,
                response_data=response_data,
            )
        elif 500 <= response.status_code < 600:
            raise TwilioServerError(
                f"Server Error: {response_data.get('message', 'An unexpected server error occurred.')}",
                status_code=response.status_code,
                response_data=response_data,
            )
        else:
            raise TwilioAPIError(
                f"Unknown API Error: {response_data.get('message', 'An unexpected error occurred.')}",
                status_code=response.status_code,
                response_data=response_data,
            )

    @retry(
        stop=stop_after_attempt(5),
        wait=wait_exponential(multiplier=1, min=4, max=60),
        retry=retry_if_exception_type((TwilioRateLimitError, TwilioServerError)),
        before_sleep=before_sleep_log(logger, logging.WARNING),
        reraise=True,
    )
    def _request(
        self,
        method: str,
        path: str,
        params: Optional[Dict[str, Any]] = None,
        json: Optional[Dict[str, Any]] = None,
        data: Optional[Union[Dict[str, Any], str]] = None,
        headers: Optional[Dict[str, str]] = None,
        timeout: Optional[int] = None,
    ) -> Dict[str, Any]:
        """
        Makes an authenticated request to the Twilio API.

        This is a private helper method that handles the core request logic,
        including authentication, error handling, and retries.

        Args:
            method: The HTTP method (e.g., 'GET', 'POST', 'PUT', 'DELETE').
            path: The API endpoint path (e.g., '/2010-04-01/Accounts/{AccountSid}/Messages.json').
            params: Dictionary of query parameters.
            json: Dictionary to be sent as a JSON body.
            data: Dictionary or string to be sent as form-encoded data.
            headers: Additional HTTP headers.
            timeout: Request timeout for this specific request in seconds.
                     Defaults to the client's configured timeout.

        Returns:
            The JSON response from the API.

        Raises:
            TwilioAPIError: If the API returns an error status code.
            requests.RequestException: For network-related errors (e.g., connection issues, timeouts).
        """
        url = f"{self.base_url}{path}"
        _timeout = timeout if timeout is not None else self.timeout

        request_headers = {"Accept": "application/json"}
        if headers:
            request_headers.update(headers)

        logger.debug(f"Request: {method} {url}, Params: {params}, JSON: {json}, Data: {data}, Headers: {request_headers}")

        try:
            response = self._session.request(
                method=method,
                url=url,
                params=params,
                json=json,
                data=data,
                headers=request_headers,
                timeout=_timeout,
            )
            logger.debug(f"Response: Status {response.status_code}, Body: {response.text}")
            return self._handle_response(response)
        except requests.exceptions.Timeout as e:
            logger.error(f"Request timed out after {_timeout} seconds: {e}")
            raise TwilioAPIError(f"Request timed out: {e}", response_data={"error": "Timeout"}) from e
        except requests.exceptions.ConnectionError as e:
            logger.error(f"Connection error: {e}")
            raise TwilioAPIError(f"Connection error: {e}", response_data={"error": "Connection Error"}) from e
        except requests.exceptions.RequestException as e:
            logger.error(f"An unexpected request error occurred: {e}")
            raise TwilioAPIError(f"Request failed: {e}", response_data={"error": "Request Failed"}) from e

    # --- Generic HTTP Methods (for future specific endpoint implementations) ---

    def get(
        self,
        path: str,
        params: Optional[Dict[str, Any]] = None,
        headers: Optional[Dict[str, str]] = None,
        timeout: Optional[int] = None,
    ) -> Dict[str, Any]:
        """Performs a GET request."""
        return self._request("GET", path, params=params, headers=headers, timeout=timeout)

    def post(
        self,
        path: str,
        json: Optional[Dict[str, Any]] = None,
        data: Optional[Union[Dict[str, Any], str]] = None,
        headers: Optional[Dict[str, str]] = None,
        timeout: Optional[int] = None,
    ) -> Dict[str, Any]:
        """Performs a POST request."""
        return self._request("POST", path, json=json, data=data, headers=headers, timeout=timeout)

    def put(
        self,
        path: str,
        json: Optional[Dict[str, Any]] = None,
        data: Optional[Union[Dict[str, Any], str]] = None,
        headers: Optional[Dict[str, str]] = None,
        timeout: Optional[int] = None,
    ) -> Dict[str, Any]:
        """Performs a PUT request."""
        return self._request("PUT", path, json=json, data=data, headers=headers, timeout=timeout)

    def delete(
        self,
        path: str,
        params: Optional[Dict[str, Any]] = None,
        headers: Optional[Dict[str, str]] = None,
        timeout: Optional[int] = None,
    ) -> Dict[