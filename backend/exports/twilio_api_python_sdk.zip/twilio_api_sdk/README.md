# Twilio API Python SDK Wrapper

This document provides a comprehensive guide to using the Python SDK wrapper for the Twilio API. This client is designed to offer a robust and user-friendly interface for interacting with Twilio services, incorporating best practices for reliability and maintainability.

## Features

*   **Simplified API Interaction**: Abstract away direct HTTP requests.
*   **Authentication**: Handles Twilio's Basic Authentication automatically.
*   **Robust Error Handling**: Custom exceptions for different API error types.
*   **Automatic Retries**: Configurable retry strategy with exponential backoff for transient errors (network issues, server errors, rate limits).
*   **Configurable Timeouts**: Set global or per-request timeouts.
*   **Logging**: Integrated logging for request/response details and errors.

## Prerequisites

*   Python 3.7+
*   Your Twilio Account SID and Auth Token.

## Installation

This SDK wrapper is provided as a Python module. You can integrate it into your project by saving the provided code (e.g., as `twilio_client.py`) and installing the necessary dependencies.

1.  **Save the SDK code**: Save the provided Python code into a file named `twilio_client.py` in your project directory.

2.  **Install dependencies**: The wrapper relies on the `requests` library for HTTP communication and `tenacity` for robust retry logic. Install them using pip:

    ```bash
    pip install requests tenacity
    ```

## Initialization & Authentication

To start using the Twilio API, you need to initialize the `TwilioClient` with your Twilio Account SID and Auth Token. These credentials are used for Basic Authentication with every API request.

```python
from twilio_client import TwilioClient

# Replace with your actual Twilio Account SID and Auth Token
ACCOUNT_SID = "ACxxxxxxxxxxxxxxxxxxxxxxxxxxxxx"  # e.g., "ACXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX"
AUTH_TOKEN = "your_auth_token"                    # e.g., "your_auth_token"

try:
    client = TwilioClient(account_sid=ACCOUNT_SID, auth_token=AUTH_TOKEN)
    print("TwilioClient initialized successfully.")
except Exception as e:
    print(f"Failed to initialize TwilioClient: {e}")

# You can also configure advanced settings during initialization:
# client = TwilioClient(
#     account_sid=ACCOUNT_SID,
#     auth_token=AUTH_TOKEN,
#     base_url="https://api.twilio.com", # Optional: default is https://api.twilio.com
#     timeout=60,                        # Optional: default is 30 seconds
#     max_retries=3,                     # Optional: default is 5 retries
#     retry_wait_min=2,                  # Optional: default is 4 seconds
#     retry_wait_max=30                  # Optional: default is 60 seconds
# )
```

## Quick Start Example

This example demonstrates how to send an SMS message and list recent messages using the `TwilioClient`.

```python
from twilio_client import TwilioClient, TwilioAPIError

# Replace with your actual Twilio Account SID and Auth Token
ACCOUNT_SID = "ACxxxxxxxxxxxxxxxxxxxxxxxxxxxxx"
AUTH_TOKEN = "your_auth_token"

# Replace with your Twilio Phone Number and a recipient number
TWILIO_PHONE_NUMBER = "+15017122661" # Your Twilio phone number (e.g., +1XXXXXXXXXX)
RECIPIENT_PHONE_NUMBER = "+15558675310" # The recipient's phone number (e.g., +1XXXXXXXXXX)

client = TwilioClient(account_sid=ACCOUNT_SID, auth_token=AUTH_TOKEN)

# --- 1. Send an SMS Message ---
print("\n--- Sending an SMS Message ---")
try:
    # The path for sending messages
    messages_path = f"/2010-04-01/Accounts/{ACCOUNT_SID}/Messages.json"

    # Data payload for sending an SMS
    sms_data = {
        "To": RECIPIENT_PHONE_NUMBER,
        "From": TWILIO_PHONE_NUMBER,
        "Body": "Hello from your custom Twilio Python SDK wrapper!"
    }

    send_response = client.post(messages_path, data=sms_data)
    print(f"SMS sent successfully! SID: {send_response.get('sid')}, Status: {send_response.get('status')}")
    print(f"Full response: {send_response}")

except TwilioAPIError as e:
    print(f"Error sending SMS: {e}")
except Exception as e:
    print(f"An unexpected error occurred: {e}")

# --- 2. List Recent SMS Messages ---
print("\n--- Listing Recent SMS Messages ---")
try:
    # The path for listing messages (same as sending)
    messages_path = f"/2010-04-01/Accounts/{ACCOUNT_SID}/Messages.json"

    # Optional query parameters for filtering
    list_params = {
        "PageSize": 5, # Retrieve up to 5 messages
        # "To": RECIPIENT_PHONE_NUMBER, # Filter by recipient
        # "From": TWILIO_PHONE_NUMBER,  # Filter by sender
    }

    list_response = client.get(messages_path, params=list_params)
    print(f"Retrieved {len(list_response.get('messages', []))} messages.")

    for message in list_response.get("messages", []):
        print(f"  SID: {message.get('sid')}, From: {message.get('from')}, To: {message.get('to')}, Body: {message.get('body')[:50]}...")

except TwilioAPIError as e:
    print(f"Error listing messages: {e}")
except Exception as e:
    print(f"An unexpected error occurred: {e}")
```

## Advanced Usage

### Pagination

Twilio APIs often return paginated results. While the SDK wrapper doesn't provide an automatic iterator for pagination, you can easily implement it using the `get` method and checking the `next_page_uri` in the response.

```python
from twilio_client import TwilioClient, TwilioAPIError

ACCOUNT_SID = "ACxxxxxxxxxxxxxxxxxxxxxxxxxxxxx"
AUTH_TOKEN = "your_auth_token"

client = TwilioClient(account_sid=ACCOUNT_SID, auth_token=AUTH_TOKEN)

all_messages = []
current_path = f"/2010-04-01/Accounts/{ACCOUNT_SID}/Messages.json"
params = {"PageSize": 50} # Request 50 messages per page initially

print("--- Fetching all messages with pagination ---")
try:
    while current_path:
        print(f"Fetching page from: {current_path}")
        response = client.get(current_path, params=params)
        messages_on_page = response.get("messages", [])
        all_messages.extend(messages_on_page)

        # Twilio's next_page_uri is a full URL, we need to extract the path and query
        next_page_uri = response.get("next_page_uri")
        if next_page_uri:
            # Extract only the path and query parameters from the full URL
            # The client's _request method will prepend the base_url
            current_path = next_page_uri.split(client.DEFAULT_BASE_URL)[-1]
            params = {} # Clear params as next_page_uri contains all necessary query string
        else:
            current_path = None # No more pages

    print(f"Successfully retrieved {len(all_messages)} total messages.")
    # for msg in all_messages:
    #     print(f"  - {msg.get('sid')}: {msg.get('body')[:30]}...")

except TwilioAPIError as e:
    print(f"Error during pagination: {e}")
except Exception as e:
    print(f"An unexpected error occurred during pagination: {e}")
```

### Custom Request Timeouts

You can configure request timeouts at two levels:

1.  **Client-level**: Set a default timeout for all requests when initializing the `TwilioClient`.
2.  **Per-request**: Override the client-level timeout for a specific request.

```python
from twilio_client import TwilioClient, TwilioAPIError

ACCOUNT_SID = "ACxxxxxxxxxxxxxxxxxxxxxxxxxxxxx"
AUTH_TOKEN = "your_auth_token"

# Client with a default timeout of 10 seconds
client_with_timeout = TwilioClient(account_sid=ACCOUNT_SID, auth_token=AUTH_TOKEN, timeout=10)

try:
    # This request will use the client's default timeout (10 seconds)
    response_default_timeout = client_with_timeout.get(
        f"/2010-04-01/Accounts/{ACCOUNT_SID}/Messages.json",
        params={"PageSize": 1}
    )
    print(f"Request with default timeout successful. Status: {response_default_timeout.get('status')}")

    # This request will override the client's timeout to 5 seconds
    response_custom_timeout = client_with_timeout.get(
        f"/2010-04-01/Accounts/{ACCOUNT_SID}/Calls.json",
        params={"PageSize": 1},
        timeout=5 # Override timeout for this specific request
    )
    print(f"Request with custom timeout successful. Status: {response_custom_timeout.get('status')}")

except TwilioAPIError as e:
    print(f"Twilio API Error (timeout example): {e}")
except Exception as e:
    print(f"An unexpected error occurred (timeout example): {e}")
```

### Error Retry Strategies

The `TwilioClient` is configured with automatic retry logic using `tenacity` for transient errors. It retries on network errors (`requests.exceptions.ConnectionError`, `requests.exceptions.Timeout`), and server-side errors (HTTP 5xx status codes), including `TwilioRateLimitError` (429).

You can configure the retry behavior during client initialization:

*   `max_retries`: The maximum number of retry attempts (default: 5).
*   `retry_wait_min`: Minimum time to wait between retries in seconds (default: 4).
*   `retry_wait_max`: Maximum time to wait between retries in seconds (default: 60).

The client uses an exponential backoff strategy, meaning the wait time between retries increases exponentially.

```python
from twilio_client import TwilioClient, TwilioAPIError

ACCOUNT_SID = "ACxxxxxxxxxxxxxxxxxxxxxxxxxxxxx"
AUTH_TOKEN = "your_auth_token"

# Initialize client with custom retry settings
# This client will retry up to 3 times, waiting between 2 and 30 seconds
# with exponential backoff.
client_with_custom_retries = TwilioClient(
    account_sid=ACCOUNT_SID,
    auth_token=AUTH_TOKEN,
    max_retries=3,
    retry_wait_min=2,
    retry_wait_max=30
)

print("\n--- Demonstrating Retry Strategy (simulated) ---")
# In a real scenario, this would handle transient network issues or 5xx errors.
# For demonstration, let's imagine a call that might fail initially.
try:
    # This call will automatically retry if it encounters a retryable error
    # (e.g., a 500 Internal Server Error or a network timeout).
    response = client_with_custom_retries.get(
        f"/2010